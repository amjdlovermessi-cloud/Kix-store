/* Public browser configuration only. Never put the Supabase service-role key here. */
window.KIX_CONFIG = {
  supabaseUrl: 'https://xtewgkfwivdonaaozbkc.supabase.co',
  supabaseAnonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh0ZXdna2Z3aXZkb25hYW96YmtjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM3NzY5MDAsImV4cCI6MjEwOTM1MjkwMH0.9KbmaHtWpsm17A1_6Y-I2QTFJLCf7tC9zmAAY5n3PJA',
  currency: 'IQD',
  whatsapp: '9647751689317',
  telegram: 'WARBOY7'
};
