# Kix Store Independent

Independent Arabic RTL digital-goods storefront. Frontend hosted on GitHub Pages, with Supabase Auth/Postgres/Storage and an Edge Function for trusted order creation.

**Read [`SETUP-AR.md`](SETUP-AR.md) before deployment.** The site is not a YouCan theme and cannot be installed in YouCan. Configure Supabase first, then publish the repository with GitHub Pages.

## Quick start

1. Run `supabase/schema.sql` in Supabase SQL Editor.
2. Create an owner user in Supabase Auth and promote its profile role to `owner` (instructions in SETUP-AR.md).
3. Add Supabase Project URL and anon key to `config.js`.
4. Deploy `supabase/functions/create-order` with Supabase CLI.
5. Push the project root to GitHub `main`; GitHub Actions deploys Pages.

Never expose the Supabase service-role key in browser code or GitHub Pages.
