import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: { ...cors, 'Content-Type': 'application/json' } });
  try {
    const body = await req.json();
    const name = String(body.customer_name || '').trim();
    const phone = String(body.phone || '').trim();
    const email = String(body.email || '').trim();
    const notes = String(body.notes || '').trim().slice(0, 1000);
    const payment = String(body.payment_method || '');
    const items = Array.isArray(body.items) ? body.items : [];
    if (name.length < 2 || name.length > 100 || phone.length < 7 || phone.length > 30) throw new Error('يرجى إدخال الاسم ورقم الهاتف بصورة صحيحة.');
    if (!['asiacell','superqi','dizly'].includes(payment)) throw new Error('طريقة الدفع غير معتمدة.');
    if (!items.length || items.length > 30) throw new Error('السلة فارغة أو تحتوي على عدد كبير من المنتجات.');
    const quantities = new Map<string, number>();
    for (const item of items) {
      const id = String(item.product_id || '');
      const qty = Number(item.quantity);
      if (!/^[0-9a-f-]{36}$/i.test(id) || !Number.isInteger(qty) || qty < 1 || qty > 20) throw new Error('بيانات أحد المنتجات غير صحيحة.');
      quantities.set(id, (quantities.get(id) || 0) + qty);
    }
    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const ids = [...quantities.keys()];
    const { data: products, error: pErr } = await supabase.from('products').select('id,name,price_iqd,active').in('id', ids);
    if (pErr) throw pErr;
    if (!products || products.length !== ids.length || products.some(p => !p.active)) throw new Error('أحد المنتجات لم يعد متوفراً. حدّث السلة وحاول مجدداً.');
    const rows = products.map(p => ({ product_id: p.id, product_name: p.name, quantity: quantities.get(p.id)!, unit_price_iqd: Number(p.price_iqd) }));
    const total = rows.reduce((sum, r) => sum + r.quantity * r.unit_price_iqd, 0);
    if (!Number.isSafeInteger(total) || total <= 0) throw new Error('تعذر حساب قيمة الطلب.');
    const suffix = crypto.randomUUID().replaceAll('-', '').slice(0, 7).toUpperCase();
    const orderNumber = `KIX-${new Date().toISOString().slice(2,10).replaceAll('-','')}-${suffix}`;
    const { data: order, error: oErr } = await supabase.from('orders').insert({ order_number: orderNumber, customer_name: name, phone, email, notes, payment_method: payment, total_iqd: total, status: 'pending' }).select('id,order_number,total_iqd,status').single();
    if (oErr) throw oErr;
    const { error: iErr } = await supabase.from('order_items').insert(rows.map(r => ({ ...r, order_id: order.id })));
    if (iErr) { await supabase.from('orders').delete().eq('id', order.id); throw iErr; }
    return new Response(JSON.stringify({ order }), { headers: { ...cors, 'Content-Type': 'application/json' } });
  } catch (err) {
    return new Response(JSON.stringify({ error: err instanceof Error ? err.message : 'تعذر تسجيل الطلب.' }), { status: 400, headers: { ...cors, 'Content-Type': 'application/json' } });
  }
});
