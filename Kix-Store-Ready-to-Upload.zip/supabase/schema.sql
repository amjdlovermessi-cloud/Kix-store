-- Kix Store independent backend schema for Supabase PostgreSQL.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role text not null default 'customer' check (role in ('customer','manager','owner')),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, display_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name',''), 'customer')
  on conflict (id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role in ('owner','manager'));
$$;
create or replace function public.is_owner() returns boolean
language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'owner');
$$;

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  slug text unique,
  name text not null,
  subtitle text default '',
  image_url text default '',
  active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.categories(id) on delete set null,
  name text not null,
  description text default '',
  price_iqd bigint not null check (price_iqd >= 0),
  image_url text default '',
  badge text default '',
  active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  customer_name text not null,
  phone text not null,
  email text default '',
  notes text default '',
  payment_method text not null check (payment_method in ('asiacell','superqi','dizly')),
  status text not null default 'pending' check (status in ('pending','paid','processing','completed','cancelled')),
  total_iqd bigint not null check (total_iqd >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  quantity integer not null check (quantity between 1 and 20),
  unit_price_iqd bigint not null check (unit_price_iqd >= 0)
);
create table if not exists public.site_settings (
  key text primary key,
  value text not null,
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.site_settings enable row level security;

-- Profiles: users can read their own role; no browser-side role escalation.
drop policy if exists "read own profile" on public.profiles;
create policy "read own profile" on public.profiles for select to authenticated using (id = auth.uid() or public.is_owner());
-- Catalog is public for active rows; staff can manage all rows.
drop policy if exists "public read active categories" on public.categories;
create policy "public read active categories" on public.categories for select to anon, authenticated using (active = true or public.is_staff());
drop policy if exists "staff manage categories" on public.categories;
create policy "staff manage categories" on public.categories for all to authenticated using (public.is_staff()) with check (public.is_staff());
drop policy if exists "public read active products" on public.products;
create policy "public read active products" on public.products for select to anon, authenticated using (active = true or public.is_staff());
drop policy if exists "staff manage products" on public.products;
create policy "staff manage products" on public.products for all to authenticated using (public.is_staff()) with check (public.is_staff());
-- Orders are private: only store staff can inspect or update them. Public checkout uses Edge Function.
drop policy if exists "staff read orders" on public.orders;
create policy "staff read orders" on public.orders for select to authenticated using (public.is_staff());
drop policy if exists "staff update orders" on public.orders;
create policy "staff update orders" on public.orders for update to authenticated using (public.is_staff()) with check (public.is_staff());
drop policy if exists "staff read order items" on public.order_items;
create policy "staff read order items" on public.order_items for select to authenticated using (public.is_staff());
drop policy if exists "public read payment settings" on public.site_settings;
create policy "public read payment settings" on public.site_settings for select to anon, authenticated using (true);
drop policy if exists "owner manage payment settings" on public.site_settings;
create policy "owner manage payment settings" on public.site_settings for all to authenticated using (public.is_owner()) with check (public.is_owner());

-- Product image bucket. Public can view product photos; only staff can upload/change/delete.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('product-images','product-images',true,6291456,array['image/png','image/jpeg','image/webp'])
on conflict (id) do update set public=true,file_size_limit=6291456,allowed_mime_types=array['image/png','image/jpeg','image/webp'];
drop policy if exists "public view product images" on storage.objects;
create policy "public view product images" on storage.objects for select to anon, authenticated using (bucket_id='product-images');
drop policy if exists "staff upload product images" on storage.objects;
create policy "staff upload product images" on storage.objects for insert to authenticated with check (bucket_id='product-images' and public.is_staff());
drop policy if exists "staff update product images" on storage.objects;
create policy "staff update product images" on storage.objects for update to authenticated using (bucket_id='product-images' and public.is_staff()) with check (bucket_id='product-images' and public.is_staff());
drop policy if exists "staff delete product images" on storage.objects;
create policy "staff delete product images" on storage.objects for delete to authenticated using (bucket_id='product-images' and public.is_staff());

-- Public payment instructions supplied by the store owner. Edit them in the owner panel.
insert into public.site_settings(key,value) values
('asiacell_number','07751669317'),
('superqi_reference','2427128562'),
('dizly_reference','2427128562'),
('whatsapp_number','9647751689317'),
('telegram_username','WARBOY7')
on conflict (key) do nothing;

-- Seed categories. These IDs are generated and referenced by product slug in the next block.
insert into public.categories(slug,name,subtitle,image_url,sort_order) values
('ps-plus','بلايستيشن بلس','PS Plus','assets/categories/ps-plus.webp',1),('ps5','ألعاب PS5','PlayStation 5','assets/categories/ps5.webp',2),('ps4','ألعاب PS4','PlayStation 4','assets/categories/ps4.webp',3),('steam','ألعاب Steam','PC Gaming','assets/categories/steam.webp',4),('xbox','عالم Xbox','Games & Pass','assets/categories/xbox.webp',5),('subscriptions','الاشتراكات','Digital subscriptions','assets/categories/subscriptions.webp',6),('fc','عالم FC','EA SPORTS FC','assets/categories/fc.webp',7),('call-of-duty','كول أوف ديوتي','Call of Duty','assets/categories/pubg-crates.webp',8),('pubg','عالم ببجي','PUBG · UC','assets/categories/pubg.webp',9),('fortnite','فورتنايت','V-Bucks','assets/categories/fortnite.webp',10),('free-fire','فري فاير','Diamonds','assets/categories/free-fire.webp',11),('mobile-legends','موبايل ليجندز','Diamonds','assets/categories/mobile-legends.webp',12),('valorant','فالورانت','Points','assets/categories/valorant.webp',13),('gta','قراند','GTA Online','assets/categories/gta.webp',14),('red-dead','ريد ديد','Red Dead','assets/categories/red-dead.webp',15),('elden-ring','إلدن رينغ','Elden Ring','assets/categories/elden-ring.webp',16),('overwatch','أوفر واتش','Overwatch','assets/categories/marvel-rivals.webp',17),('rainbow-six','رينبو 6','Siege X','assets/categories/rainbow-six.webp',18),('marvel-rivals','مارفل رايفلز','Marvel Rivals','assets/categories/marvel-rivals.webp',19),('rocket-league','روكيت ليق','Rocket League','assets/categories/rocket-league.webp',20),('forza','فورزا','Forza Horizon','assets/categories/forza-racing.webp',21),('dark-souls','دارك سولز','Dark Souls','assets/categories/dark-souls.webp',22),('jawaker','جواكر','Jawaker','assets/categories/jawaker.webp',23),('gift-cards','بطاقات رقمية','Gift Cards','assets/categories/gift-cards.webp',24),('streaming','المشاهدة','Streaming','assets/categories/streaming.webp',25),('software','برامج PC','PC Software','assets/categories/software.webp',26),('ai','الذكاء الاصطناعي','AI Tools','assets/categories/ai-tools.webp',27),('social','خدمات التواصل','Social Services','assets/categories/social-services.webp',28),('courses-ebooks','الدورات والكتب','Digital Learning','assets/categories/courses-ebooks.webp',29),('app-currency','عملات التطبيقات','App Credits','assets/categories/app-currency.webp',30)
on conflict (slug) do nothing;

insert into public.products(name,description,price_iqd,image_url,badge,sort_order,category_id)
select v.name,v.description,v.price_iqd,v.image_url,v.badge,v.sort_order,c.id from (values
('EA SPORTS FC 27 PS5','منتج رقمي. يرجى تحديد المنصة والمنطقة قبل إتمام الطلب.',75000,'assets/products/fc-27.webp','الأكثر طلباً',1,'fc'),
('PlayStation Plus 12 شهر','اشتراك بلايستيشن. تأكد من توافق المنطقة.',95000,'assets/products/playstation-plus.webp','',2,'ps-plus'),
('PUBG Mobile UC','شحن شدات PUBG Mobile.',15000,'assets/products/pubg-uc.webp','الأكثر طلباً',3,'pubg'),
('Fortnite V-Bucks','بطاقات V-Bucks لفورتنايت.',20000,'assets/products/fortnite-vbucks.webp','',4,'fortnite'),
('Red Dead Redemption 2','لعبة رقمية. اختر المنصة والمنطقة.',30000,'assets/products/red-dead-redemption-2.webp','',5,'red-dead'),
('Elden Ring','لعبة رقمية. اختر المنصة والمنطقة.',45000,'assets/products/elden-ring.webp','',6,'elden-ring'),
('Forza Horizon 5','لعبة سباقات رقمية.',40000,'assets/products/forza-horizon-5.webp','',7,'forza'),
('Call of Duty Black Ops 7','لعبة أكشن رقمية.',80000,'assets/products/call-of-duty-black-ops-7.webp','',8,'call-of-duty'),
('Marvel Rivals','محتوى رقمي للعبة.',18000,'assets/products/marvel-rivals.webp','',9,'marvel-rivals'),
('Mobile Legends Diamonds','شحن ألماس Mobile Legends.',10000,'assets/products/mobile-legends.webp','',10,'mobile-legends'),
('Rainbow Six Siege X','محتوى رقمي للعبة.',35000,'assets/products/rainbow-six-siege-x.webp','',11,'rainbow-six'),
('Rocket League Credits','رصيد Rocket League.',12000,'assets/products/rocket-league.webp','',12,'rocket-league'),
('Free Fire Diamonds','شحن جواهر Free Fire.',10000,'assets/products/free-fire-diamonds.webp','',13,'free-fire'),
('Netflix Subscription','اشتراك بث رقمي. راجع المدة والمنطقة قبل الطلب.',15000,'assets/products/netflix.webp','',14,'subscriptions')
) as v(name,description,price_iqd,image_url,badge,sort_order,slug)
join public.categories c on c.slug=v.slug
where not exists(select 1 from public.products p where p.name=v.name);
