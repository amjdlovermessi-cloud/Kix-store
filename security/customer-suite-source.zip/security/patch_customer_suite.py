from pathlib import Path
import sys
site=Path(sys.argv[1]).resolve();repo=Path(__file__).resolve().parent.parent
src=repo/'kix-customer-suite.js'
if not src.is_file():raise SystemExit(f'Missing {src}')
(site/'kix-customer-suite.js').write_bytes(src.read_bytes())
for name in ('index.html','owner.html'):
 p=site/name
 if not p.is_file():raise SystemExit(f'Missing {p}')
 html=p.read_text(encoding='utf-8')
 if 'kix-customer-suite.js' not in html:
  html=html.replace('</head>','<script src="kix-customer-suite.js?v=20261125-1" defer></script>\n</head>',1)
 p.write_text(html,encoding='utf-8')
print('Customer suite installed in storefront and owner panel.')
